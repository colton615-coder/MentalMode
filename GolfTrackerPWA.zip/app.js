/* Minimal JS app: GPS shot marking, distances, score, CSV export, simple dispersion. */
let map, round = null, holeIndex = 1, markers = {}, polylines = {}, shotsByHole = {};
const holeNumEl = document.getElementById('holeNum');
const strokesEl = document.getElementById('strokes');
const puttsEl = document.getElementById('putts');
const penaltiesEl = document.getElementById('penalties');
const bannerEl = document.getElementById('banner');

function metersToYards(m) { return m * 1.09361; }
function hav(a, b) {
  const R = 6371000;
  const toRad = d => d * Math.PI / 180;
  const dLat = toRad(b.lat - a.lat), dLon = toRad(b.lon - a.lon);
  const s1 = Math.sin(dLat/2), s2 = Math.sin(dLon/2);
  const x = s1*s1 + Math.cos(toRad(a.lat))*Math.cos(toRad(b.lat))*s2*s2;
  return 2*R*Math.asin(Math.sqrt(x));
}
function toXY(c) {
  const R = 6371000;
  const x = c.lon * Math.PI/180 * R * Math.cos(c.lat * Math.PI/180);
  const y = c.lat * Math.PI/180 * R;
  return {x,y};
}
function computeDispersion(start, end, target) {
  const s = toXY(start), e = toXY(end), t = toXY(target);
  const vx = t.x - s.x, vy = t.y - s.y;
  const vlen = Math.max(1e-6, Math.hypot(vx, vy));
  const ux = vx / vlen, uy = vy / vlen;
  const px = e.x - s.x, py = e.y - s.y;
  const forward = px*ux + py*uy;
  const lateral = px*(-uy) + py*ux;
  return { forward: metersToYards(forward), lateral: metersToYards(lateral) };
}

function saveState() {
  localStorage.setItem('golfRound', JSON.stringify({ round, holeIndex, shotsByHole, scores: getScores() }));
}
function loadState() {
  try {
    const s = JSON.parse(localStorage.getItem('golfRound'));
    if (!s) return;
    round = s.round; holeIndex = s.holeIndex || 1; shotsByHole = s.shotsByHole || {};
    const scores = s.scores || {};
    strokesEl.value = scores.strokes || 0;
    puttsEl.value = scores.putts || 0;
    penaltiesEl.value = scores.penalties || 0;
    holeNumEl.textContent = holeIndex;
  } catch {}
}

function getScores() {
  return { strokes: Number(strokesEl.value), putts: Number(puttsEl.value), penalties: Number(penaltiesEl.value) };
}

function setBanner(msg) { bannerEl.textContent = msg || ''; }

function ensureHoleData(i) {
  if (!shotsByHole[i]) shotsByHole[i] = [];
  if (!markers[i]) markers[i] = [];
}

function drawHole(i) {
  // clear
  (markers[i]||[]).forEach(m => m.remove());
  (polylines[i]||[]).forEach(l => l.remove());
  markers[i] = []; polylines[i] = [];
  const shots = shotsByHole[i] || [];
  for (let s=0; s<shots.length; s++) {
    const m = L.marker([shots[s].lat, shots[s].lon], { draggable: true }).addTo(map);
    m.bindTooltip(`Shot ${s+1}`, {permanent:false});
    m.on('dragend', e => {
      const {lat, lng} = e.target.getLatLng();
      shots[s].lat = lat; shots[s].lon = lng;
      refreshPolylines(i); saveState();
    });
    markers[i].push(m);
  }
  refreshPolylines(i);
}

function refreshPolylines(i) {
  (polylines[i]||[]).forEach(l => l.remove());
  polylines[i] = [];
  const shots = shotsByHole[i] || [];
  if (shots.length > 1) {
    const latlngs = shots.map(s => [s.lat, s.lon]);
    const line = L.polyline(latlngs, { color: '#4aa3ff' }).addTo(map);
    polylines[i].push(line);
  }
}

function setHole(i) {
  holeIndex = i;
  holeNumEl.textContent = holeIndex;
  drawHole(i);
  saveState();
}

function currentGPS(cb) {
  if (!navigator.geolocation) return setBanner('Location not supported');
  navigator.geolocation.getCurrentPosition(
    pos => cb({ lat: pos.coords.latitude, lon: pos.coords.longitude, acc: pos.coords.accuracy }),
    err => setBanner('Location error: ' + err.message),
    { enableHighAccuracy: true, maximumAge: 10000, timeout: 10000 }
  );
}

function mark(type) {
  ensureHoleData(holeIndex);
  currentGPS(loc => {
    if (loc.acc > 20) setBanner('Weak GPS (~' + Math.round(loc.acc) + 'm). You can drag the pin to refine.');
    const shot = { lat: loc.lat, lon: loc.lon, type };
    shotsByHole[holeIndex].push(shot);
    const m = L.marker([shot.lat, shot.lon], { draggable: true }).addTo(map);
    m.on('dragend', e => {
      const {lat, lng} = e.target.getLatLng();
      shot.lat = lat; shot.lon = lng;
      refreshPolylines(holeIndex); saveState();
    });
    (markers[holeIndex]||[]).push(m);
    refreshPolylines(holeIndex);
    saveState();
  });
}

function exportCSV() {
  let rows = ["Hole,Seq,Lat,Lon,Type,DistanceYds"];
  for (const h in shotsByHole) {
    const arr = shotsByHole[h];
    for (let i=0; i<arr.length; i++) {
      let dist = '';
      if (i>0) {
        const a = arr[i-1], b = arr[i];
        dist = Math.round(metersToYards(hav(a,b)));
      }
      rows.push([h, i+1, arr[i].lat, arr[i].lon, arr[i].type||'shot', dist].join(','));
    }
  }
  const blob = new Blob([rows.join("\n")], { type: "text/csv" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = 'round.csv'; a.click();
  URL.revokeObjectURL(url);
}

function computeSummary() {
  // basic totals
  const scores = getScores();
  let totalShots = 0;
  Object.values(shotsByHole).forEach(arr => totalShots += arr.length);
  // club distances derived by consecutive points (we don't have club names here, just Shot/ Putt/ Penalty)
  // We treat 'Putt' as separate.
  let carry = [];
  for (const h in shotsByHole) {
    const arr = shotsByHole[h];
    for (let i=1; i<arr.length; i++) {
      const d = Math.round(metersToYards(hav(arr[i-1], arr[i])));
      if ((arr[i].type||'shot') === 'shot') carry.push(d);
    }
  }
  const avg = carry.length ? Math.round(carry.reduce((a,b)=>a+b,0)/carry.length) : 0;
  return { totalShots, scores, avgCarry: avg };
}

function showSummary() {
  const s = computeSummary();
  const el = document.getElementById('summaryPanel');
  const cards = document.getElementById('cards');
  cards.innerHTML = '';
  const mk = (t,v)=>{ const d=document.createElement('div');d.className='card';d.innerHTML=`<h3>${t}</h3><p>${v}</p>`; return d; };
  cards.append(mk('Total Shots', s.totalShots));
  cards.append(mk('Strokes', s.scores.strokes));
  cards.append(mk('Putts', s.scores.putts));
  cards.append(mk('Penalties', s.scores.penalties));
  cards.append(mk('Avg Carry (yd)', s.avgCarry));
  el.classList.remove('hidden');

  drawDispersionCanvas();
  drawClubCanvas();
}

function closeSummary() {
  document.getElementById('summaryPanel').classList.add('hidden');
}

function drawClubCanvas() {
  const canvas = document.getElementById('clubChart');
  const ctx = canvas.getContext('2d');
  ctx.clearRect(0,0,canvas.width,canvas.height);
  // simple histogram of carries
  let carries = [];
  for (const h in shotsByHole) {
    const arr = shotsByHole[h];
    for (let i=1; i<arr.length; i++) {
      const d = Math.round(metersToYards(hav(arr[i-1], arr[i])));
      if ((arr[i].type||'shot') === 'shot') carries.push(d);
    }
  }
  if (!carries.length) return;
  carries.sort((a,b)=>a-b);
  const w = canvas.width, h = canvas.height, max = Math.max(...carries);
  ctx.strokeStyle = '#6fbf73'; ctx.lineWidth = 10;
  const barW = w / carries.length;
  carries.forEach((v, i) => {
    const barH = (v / max) * (h - 20);
    ctx.beginPath();
    ctx.moveTo(i*barW + barW/2, h);
    ctx.lineTo(i*barW + barW/2, h - barH);
    ctx.stroke();
  });
  ctx.fillStyle = '#9aa4b2';
  ctx.fillText('Carries (yd)', 8, 14);
}

function drawDispersionCanvas() {
  const canvas = document.getElementById('dispersionChart');
  const ctx = canvas.getContext('2d');
  ctx.clearRect(0,0,canvas.width,canvas.height);
  const w = canvas.width, h = canvas.height;
  // build points per hole: start = first shot, target = last shot, points = every hop
  let points = [];
  for (const hKey in shotsByHole) {
    const arr = shotsByHole[hKey];
    if (arr.length < 2) continue;
    const start = arr[0], target = arr[arr.length-1];
    for (let i=1; i<arr.length; i++) {
      const res = computeDispersion(start, arr[i], target);
      points.push(res);
    }
  }
  if (!points.length) return;
  // scales: x = +/-50 yd, y = 0..300 yd
  const xScale = x => (x + 50) / 100 * w;
  const yScale = y => h - (y / 300) * h;

  // scatter
  ctx.fillStyle = '#4aa3ff';
  points.forEach(p => {
    ctx.beginPath();
    ctx.arc(xScale(p.lateral), yScale(p.forward), 3, 0, Math.PI*2);
    ctx.fill();
  });

  // simple ellipse (1-sigma) for all points combined
  const mean = ptsMean(points);
  const cov = ptsCov(points, mean);
  const ell = ellipseFromCov(mean, cov);
  if (ell) drawEllipse(ctx, ell, xScale, yScale);
}

function ptsMean(ps) {
  const n = ps.length;
  let sx=0, sy=0;
  for (const p of ps) { sx += p.lateral; sy += p.forward; }
  return { x: sx/n, y: sy/n };
}
function ptsCov(ps, m) {
  const n = ps.length;
  let cxx=0, cyy=0, cxy=0;
  for (const p of ps) {
    const dx = p.lateral - m.x, dy = p.forward - m.y;
    cxx += dx*dx; cyy += dy*dy; cxy += dx*dy;
  }
  cxx /= (n-1); cyy /= (n-1); cxy /= (n-1);
  return { cxx, cyy, cxy };
}
function ellipseFromCov(mean, cov) {
  const tr = cov.cxx + cov.cyy;
  const det = cov.cxx*cov.cyy - cov.cxy*cov.cxy;
  const term = Math.sqrt(Math.max(0, tr*tr/4 - det));
  const l1 = tr/2 + term, l2 = tr/2 - term;
  const angle = Math.atan2(l1 - cov.cxx, cov.cxy || 1e-6);
  return { cx: mean.x, cy: mean.y, rx: Math.sqrt(Math.max(l1,0)), ry: Math.sqrt(Math.max(l2,0)), angle };
}
function drawEllipse(ctx, e, xScale, yScale) {
  ctx.save();
  ctx.translate(xScale(e.cx), yScale(e.cy));
  ctx.rotate(-e.angle); // invert y axis effect
  ctx.strokeStyle = 'rgba(111,191,115,0.9)';
  ctx.fillStyle = 'rgba(111,191,115,0.25)';
  ctx.lineWidth = 2;
  ctx.beginPath();
  // radii are in yards; scale to pixels with approximate scale around center
  const sx = (xScale(e.cx+e.rx) - xScale(e.cx));
  const sy = (yScale(e.cy) - yScale(e.cy+e.ry));
  ctx.ellipse(0, 0, Math.abs(sx), Math.abs(sy), 0, 0, Math.PI*2);
  ctx.fill(); ctx.stroke();
  ctx.restore();
}

document.getElementById('btnStart').onclick = () => {
  if (round) return;
  round = { id: Date.now() };
  shotsByHole = {}; holeIndex = 1;
  setHole(1);
  saveState();
  document.getElementById('btnStart').disabled = true;
  document.getElementById('btnEnd').disabled = false;
  setBanner('Round started. Tap Mark Shot, or tap map to drop a pin.');
};
document.getElementById('btnEnd').onclick = () => {
  round = null;
  saveState();
  document.getElementById('btnStart').disabled = false;
  document.getElementById('btnEnd').disabled = true;
  setBanner('Round ended.');
};

document.getElementById('markShot').onclick = ()=>mark('shot');
document.getElementById('markPutt').onclick = ()=>mark('putt');
document.getElementById('markPenalty').onclick = ()=>mark('penalty');

document.getElementById('prevHole').onclick = ()=> setHole(Math.max(1, holeIndex-1));
document.getElementById('nextHole').onclick = ()=> setHole(Math.min(18, holeIndex+1));

document.getElementById('exportCSV').onclick = exportCSV;
document.getElementById('summary').onclick = showSummary;
document.getElementById('closeSummary').onclick = closeSummary;

function bootMap() {
  map = L.map('map', { zoomControl: false });
  // OSM tiles (fair use)
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19, attribution: '&copy; OpenStreetMap'
  }).addTo(map);
  map.setView([40.0,-100.0], 4);

  map.on('click', e => {
    // tap-to-set manual shot
    ensureHoleData(holeIndex);
    const shot = { lat: e.latlng.lat, lon: e.latlng.lng, type:'shot' };
    shotsByHole[holeIndex].push(shot);
    const m = L.marker([shot.lat, shot.lon], { draggable: true }).addTo(map);
    m.on('dragend', ev => {
      const {lat, lng} = ev.target.getLatLng();
      shot.lat = lat; shot.lon = lng; refreshPolylines(holeIndex); saveState();
    });
    (markers[holeIndex]||[]).push(m);
    refreshPolylines(holeIndex);
    saveState();
  });

  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(p => {
      map.setView([p.coords.latitude, p.coords.longitude], 16);
    });
  }
}

window.addEventListener('load', () => {
  loadState();
  bootMap();
  setHole(holeIndex);
});
